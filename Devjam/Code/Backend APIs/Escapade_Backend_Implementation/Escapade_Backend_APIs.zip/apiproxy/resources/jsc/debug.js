var checkedIn = context.getVariable("appRequest");
print(checkedIn);